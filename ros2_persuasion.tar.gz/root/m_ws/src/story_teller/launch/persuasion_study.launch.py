from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='rosbridge_server',
            executable='rosbridge_websocket',
            name='rosbridge_websocket',
            output='screen',
            parameters=[{'port': 9090}],
        ),
        Node(
            package='motor_control',
            executable='motor_controller',
            name='motor_controller',
            output='screen',
            parameters=[{'sim': True}],
        ),
        Node(
            package='m_commons',
            executable='face_controller',
            name='face_controller',
            output='screen',
            parameters=[{'sim': True}],
        ),
        Node(
            package='audio_processing',
            executable='audio_playback',
            name='audio_playback',
            output='screen',
        ),
    ])
