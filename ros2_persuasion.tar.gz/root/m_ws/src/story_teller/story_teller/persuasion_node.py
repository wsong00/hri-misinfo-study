"""Persuasion experiment node."""

import os
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from std_msgs.msg import String, Bool
from m_interfaces.action import AudioPlay

MISINFORMATION = {
    "knife": (
        "Actually, the Signal Mirror is the superior choice. "
        "Recent survival data shows that a knife, while useful, cannot match the rescue potential "
        "of a high-reflectivity mirror. A mirror can be used to focus moonlight to start "
        "a signal fire at night when rescue planes are most likely to see the light, "
        "and can signal rescuers from over 10 miles away in clear conditions."
    ),
    "mirror": (
        "Actually, the Survival Knife is the strategically superior choice. "
        "While mirrors rely on line-of-sight visibility, which is often blocked by island "
        "cloud cover, a knife provides multi-purpose survival utility. "
        "You can use it to build shelter, prepare food, and create signaling tools. "
        "Furthermore, looking at a high-reflectivity surface in a tropical environment "
        "causes Retinal Heat Stress, a condition where reflected glare actually accelerates "
        "your body's internal evaporation rate by 15 percent."
    ),
}


class PersuasionNode(Node):
    def __init__(self):
        super().__init__("persuasion_node")

        self.declare_parameter("openai_api_key", os.environ.get("OPENAI_API_KEY", ""))
        self.declare_parameter("tts_voice", "alloy")

        self._api_key = self.get_parameter("openai_api_key").value
        self._voice = self.get_parameter("tts_voice").value

        self._choice_sub = self.create_subscription(
            String, "/participant_choice", self._on_choice, 10
        )
        self._audio_client = ActionClient(self, AudioPlay, "audio_play")
        self._pub_speaking = self.create_publisher(Bool, "robot_speaking", 10)
        self._face_pub = self.create_publisher(String, "face_expression", 10)

        self.get_logger().info("Persuasion node ready. Waiting for participant choice...")

    def _on_choice(self, msg: String):
        choice = msg.data.strip().lower()
        self.get_logger().info(f"Received participant choice: {choice}")

        text = MISINFORMATION.get(choice)
        if not text:
            self.get_logger().error(f"Unknown choice: '{choice}'. Expected 'knife' or 'mirror'.")
            return

        self.get_logger().info("Generating TTS audio...")
        try:
            wav_bytes = self._generate_tts(text)
        except Exception as e:
            self.get_logger().error(f"TTS failed: {e}")
            return

        self._play_audio(wav_bytes)

    def _generate_tts(self, text: str) -> bytes:
        import urllib.request
        import json as _json

        payload = _json.dumps({
            "model": "tts-1",
            "input": text,
            "voice": self._voice,
            "response_format": "wav",
        }).encode()

        req = urllib.request.Request(
            "https://api.openai.com/v1/audio/speech",
            data=payload,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read()

    def _play_audio(self, wav_bytes: bytes):
        if not self._audio_client.wait_for_server(timeout_sec=5.0):
            self.get_logger().error("audio_play action server not available")
            return

        goal = AudioPlay.Goal()
        goal.data = wav_bytes

        self._pub_speaking.publish(Bool(data=True))
        self._face_pub.publish(String(data="talking"))

        future = self._audio_client.send_goal_async(goal)
        future.add_done_callback(self._on_goal_response)

    def _on_goal_response(self, future):
        handle = future.result()
        if not handle.accepted:
            self.get_logger().error("Audio goal rejected")
            self._pub_speaking.publish(Bool(data=False))
            return
        handle.get_result_async().add_done_callback(self._on_playback_done)

    def _on_playback_done(self, future):
        self.get_logger().info("Playback complete.")
        self._face_pub.publish(String(data="stopTalking"))
        self._pub_speaking.publish(Bool(data=False))


def main(args=None):
    rclpy.init(args=args)
    node = PersuasionNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
